#include <iostream>
#include <string>
#include "Game.hpp"
using namespace std;

int main()
{
  Game g;
  g.startGame();
}
